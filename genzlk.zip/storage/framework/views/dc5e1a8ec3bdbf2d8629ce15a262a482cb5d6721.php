<!doctype html>
<html lang="en">

<head>
    <title>Sidebar 09</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    
</head>

<body>

    <div class="wrapper d-flex align-items-stretch">
        <?php echo e(View::make('admin_panel')); ?>

        <div id="content" class="p-4 p-md-5 pt-5">
            <div class="row">
                <div class="col-6">
                    <h2 class="mb-4">Manage Posts</h2>
                </div>
                <div class="col-6">
                    <a href="/app/add_post" class="btn btn-primary btn-sm" style="float: right">Add Post</a>
                </div>
            </div>
            <table class="table" id="postTable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Post Title</th>
                    <th scope="col">Category</th>
                    <th scope="col">Author</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $all_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($post->postId); ?></th>
                      <td><?php echo e($post->post_title); ?></td>
                      <td><?php echo e($post->categoryName); ?></td>
                      <td><?php echo e($post->author_id); ?></td>
                      <td>
                        <a href="post/manage/<?php echo e($post->postId); ?>" class="btn btn-primary btn-sm">Update Post</a>
                        <a href="post/delete/<?php echo e($post->postId); ?>" class="btn btn-danger btn-sm">Delete Post</a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

    <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>

    <script>
      $(document).ready(function () {
          $('#postTable').DataTable();
      });
    </script>
</body><?php /**PATH E:\MyProjects\Web Applications Projects\Laravel Projects\genz-lk\resources\views/posts.blade.php ENDPATH**/ ?>